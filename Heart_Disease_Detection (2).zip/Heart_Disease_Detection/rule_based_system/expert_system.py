from experta import *

class HeartRiskExpertSystem(KnowledgeEngine):
    
    @Rule(Fact(cholesterol=P(lambda x: x > 240)), Fact(age=P(lambda x: x > 50)))
    def high_risk_cholesterol(self):
        self.declare(Fact(risk="High"))
        
    @Rule(Fact(blood_pressure=P(lambda x: x > 140)), Fact(smoking="Yes"))
    def high_risk_bp_smoking(self):
        self.declare(Fact(risk="High"))
        
    @Rule(Fact(exercise="Regular"), Fact(bmi=P(lambda x: x < 25)))
    def low_risk_exercise_bmi(self):
        self.declare(Fact(risk="Low"))
        
    def assess_risk(self, user_data):
        self.reset()
        for key, value in user_data.items():
            self.declare(Fact(**{key: value}))
        self.run()
        facts = [fact[1] for fact in self.facts.items() if isinstance(fact[1], Fact) and 'risk' in fact[1]]
        return facts[-1]['risk'] if facts else "Unknown"

# User Input
if __name__ == "__main__":
    expert_system = HeartRiskExpertSystem()
    
    user_data = {
        "cholesterol": float(input("Enter cholesterol level: ")), 
        "age": int(input("Enter age: ")), 
        "blood_pressure": float(input("Enter blood pressure: ")), 
        "smoking": input("Do you smoke? (Yes/No): ").strip().capitalize(), 
        "exercise": input("Do you exercise regularly? (Regular/No): ").strip().capitalize(), 
        "bmi": float(input("Enter BMI: "))
    }
    
    risk_level = expert_system.assess_risk(user_data)
    print(f"Predicted Risk Level: {risk_level}")

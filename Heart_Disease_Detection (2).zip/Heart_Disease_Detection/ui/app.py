import streamlit as st
import pandas as pd
import numpy as np
import joblib
from rule_based_system.expert_system import predict_with_expert_system  # Import the expert system

# Load the Decision Tree model
dt_model = joblib.load("ml_model/decision_tree_model.pkl")

# Define the Streamlit interface
st.title(" Heart Disease Detection System")
st.write("Enter your health data to assess your risk of heart disease.")

# User input
age = st.number_input("Age", min_value=1, max_value=120, value=30)
sex = st.selectbox("Sex", ["Male", "Female"])
cholesterol = st.number_input("Cholesterol level", min_value=100, max_value=500, value=200)
blood_pressure = st.number_input("Blood pressure", min_value=80, max_value=200, value=120)
smoking = st.selectbox("Do you smoke?", ["Yes", "No"])
exercise = st.selectbox("Exercise level", ["Regular", "Moderate", "Low"])

# Convert inputs to numerical format
sex = 1 if sex == "Male" else 0
smoking = 1 if smoking == "Yes" else 0
exercise_levels = {"Regular": 2, "Moderate": 1, "Low": 0}
exercise = exercise_levels[exercise]

# Format user data for the Decision Tree model
user_data = np.array([[age, sex, cholesterol, blood_pressure, smoking, exercise]])

# Prediction using Decision Tree
if st.button(" Analyze risk using Decision Tree"):
    prediction = dt_model.predict(user_data)
    risk = "⚠️ High risk" if prediction[0] == 1 else "✅ Low risk"
    st.success(f"Decision Tree result: {risk}")

# Prediction using the expert system
if st.button(" Analyze risk using Expert System"):
    expert_risk = predict_with_expert_system(age, cholesterol, blood_pressure, smoking, exercise)
    st.info(f"Expert System result: {expert_risk}")

# Note
st.write(" This system is a helpful tool and does not replace consulting a doctor.")
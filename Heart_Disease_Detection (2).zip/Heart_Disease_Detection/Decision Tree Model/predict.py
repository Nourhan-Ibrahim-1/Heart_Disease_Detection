import os
import joblib
import numpy as np

# === Automatically get the directory of this script ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# === Model path relative to this script ===
model_path = os.path.join(BASE_DIR, "heart_disease_model.pkl")

# === Load the trained model ===
try:
    model = joblib.load(model_path)
    print("✅ Model loaded successfully!\n")
except FileNotFoundError:
    print(f"❌ Error: The file '{model_path}' does not exist! Please ensure the model is trained first.")
    exit()
except Exception as e:
    print(f"❌ Error while loading the model: {e}")
    exit()

# === Get user input ===
def get_user_input():
    print("\n🔍 Please enter the required values:")

    try:
        # Collect inputs for the 14 features (without the target)
        age = float(input("Age: "))
        sex = int(input("Sex (1 = male; 0 = female): "))
        cp_1 = int(input("Chest Pain Type cp_1 (0 or 1): "))
        cp_2 = int(input("Chest Pain Type cp_2 (0 or 1): "))
        trestbps = float(input("Resting Blood Pressure: "))
        chol = float(input("Cholesterol: "))
        fbs = int(input("Fasting Blood Sugar > 120 mg/dl (1 = true; 0 = false): "))
        restecg = int(input("Resting ECG results (0, 1, 2): "))
        thalach = float(input("Max Heart Rate Achieved: "))
        exang = int(input("Exercise-induced angina (1 = yes; 0 = no): "))
        oldpeak = float(input("ST depression induced by exercise: "))
        slope_1 = int(input("Slope of the peak exercise ST segment slope_1 (0 or 1): "))
        slope_2 = int(input("Slope of the peak exercise ST segment slope_2 (0 or 1): "))
        ca = int(input("Number of major vessels colored by fluoroscopy (0-3): "))
        thal_2 = int(input("Thal 2 (1 if true, else 0): "))
        thal_3 = int(input("Thal 3 (1 if true, else 0): "))

        # === Prepare data in the correct order ===
        new_data = np.array([[thal_2, thal_3, oldpeak, exang, thalach, slope_2, ca,
                              slope_1, cp_2, sex, cp_1, age, trestbps, restecg]])
        
        return new_data

    except ValueError as e:
        print(f"\n❌ Invalid input: {e}. Please enter numeric values.")
        exit()

# === Get new input sample ===
new_sample = get_user_input()

# === Predict using the model ===
prediction = model.predict(new_sample)

# === Display result ===
if prediction[0] == 1:
    print("\n🚨 Result: The person IS at risk of heart disease!")
else:
    print("\n✅ Result: The person is NOT at risk of heart disease.")

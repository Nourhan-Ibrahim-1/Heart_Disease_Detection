import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

# Load the data
data = pd.read_csv("data/cleaned_data.csv")

# Separate features (X) from the target (y)
X = data.drop(columns=["target"])  # Assume the target column is named "heart_disease"
y = data["target"]

# Split the data into 80% training and 20% testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a Decision Tree model
model = DecisionTreeClassifier(max_depth=5, min_samples_split=10, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f" Model Accuracy: {accuracy:.2f}")
print("\n Classification Report:\n", classification_report(y_test, y_pred))

# Save the trained model
joblib.dump(model, "ml_model/heart_disease_model.pkl")
print(" Model saved to 'ml_model/heart_disease_model.pkl'")


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer

# Load the dataset
df = pd.read_csv("data/raw_data.csv")

# Show the first few rows of data
print(df.head())

# Show basic info about the dataset
print(df.info())

# Show basic statistics (mean, min, max, etc.)
print(df.describe())

# Fill missing values in restecg and oldpeak with their median values
df["restecg"].fillna(df["restecg"].median(), inplace=True)
df["oldpeak"].fillna(df["oldpeak"].median(), inplace=True)

# Scale the numeric columns so they are between 0 and 1
num_cols = ["age", "trestbps", "chol", "thalach", "oldpeak"]
scaler = MinMaxScaler()
df[num_cols] = scaler.fit_transform(df[num_cols])

# One-hot encode the categorical columns
cat_cols = ["sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal"]
encoder = ColumnTransformer(
    transformers=[("cat", OneHotEncoder(drop="first"), cat_cols)],
    remainder="passthrough"
)
df_encoded = encoder.fit_transform(df)

# Turn the encoded data back into a DataFrame with column names
feature_names = encoder.get_feature_names_out()
df_cleaned = pd.DataFrame(df_encoded, columns=feature_names)

# Save the cleaned data to a new CSV file
df_cleaned.to_csv("data/cleaned_data.csv", index=False)

print("Data cleaning is done. Saved as 'cleaned_data.csv'.")

# Show the correlation heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(df.corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

# Show histograms for each column
df.hist(bins=20, figsize=(15, 10))
plt.tight_layout()
plt.show()

# Show boxplots for each numeric column
for col in num_cols:
    plt.figure(figsize=(6, 4))
    sns.boxplot(x=df[col])
    plt.title(f"Boxplot of {col}")
    plt.show()

print("Data visualization is done.")
